package fr.youness.albumapp.data.local

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import fr.youness.ebook.model.Item

@Dao
interface AlbumDao {

    @Query("SELECT * FROM book_table")
    fun getAllAlbums(): LiveData<List<Item>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAllAlbums(albumItems: List<Item>?)

    @Query("DELETE FROM book_table")
    fun deleteAllAlbums()
}