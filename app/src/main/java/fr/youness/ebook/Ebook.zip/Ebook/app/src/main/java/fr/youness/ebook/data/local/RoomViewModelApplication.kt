package fr.youness.ebook.data.local

import android.app.Application
import android.content.Context

object RoomViewModelApplication : Application() {

    var database: AlbumDataBase? = null

    fun provideAlbumDao(context: Context): AlbumDataBase {
        return AlbumDataBase.getInstance(context)
    }

}