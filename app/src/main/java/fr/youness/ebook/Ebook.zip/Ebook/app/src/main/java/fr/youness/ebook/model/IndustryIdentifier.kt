package fr.youness.ebook.model

data class IndustryIdentifier(
    val type: String?, // OTHER
    val identifier: String? // BCUL:VD2266376
)