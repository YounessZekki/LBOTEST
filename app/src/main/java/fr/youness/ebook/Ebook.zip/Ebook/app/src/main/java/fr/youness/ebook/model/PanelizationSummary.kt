package fr.youness.ebook.model

data class PanelizationSummary(
    val containsEpubBubbles: Boolean?, // false
    val containsImageBubbles: Boolean? // false
)