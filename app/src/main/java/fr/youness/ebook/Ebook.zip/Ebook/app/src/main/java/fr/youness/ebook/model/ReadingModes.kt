package fr.youness.ebook.model

data class ReadingModes(
    val text: Boolean?, // false
    val image: Boolean? // true
)