package fr.youness.ebook.model

data class SearchInfo(
    val textSnippet: String? // Le <b>Test</b> &amp; les Loix Penales sont un boulevart qui deffend les Protestans des <br>entreprises , des conspirations , &amp; des attentats Papistiques , dés que cette <br>barriere sera ouverte il ne faut plus que les Protestans s &#39; attendent de posseder <br>aucune&nbsp;...
)