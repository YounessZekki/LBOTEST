package fr.youness.ebook.utils

const val BASE_URL = "https://www.googleapis.com/books/v1/"
const val ALBUM_URL = BASE_URL + "volumes?"
const val SPLASH_DISPLAY_LENGTH = 4000L
const val DB_NAME = "books.db"
